<?php
include 'connect.php';
session_start();

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    echo "Je hebt geen toegang tot deze pagina.";
    exit();
}

// Handle feedback deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_feedback'])) {
    $review_id = intval($_POST['review_id']);

    $sql_delete = "DELETE FROM Reviews WHERE review_id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $review_id);
    if ($stmt_delete->execute()) {
        echo "Feedback succesvol verwijderd.";
    } else {
        echo "Er is een fout opgetreden bij het verwijderen van de feedback.";
    }
}

// Fetch all feedback
$sql_feedback = "SELECT r.review_id, r.review_text, r.rating, r.review_date, p.naam AS product_name, u.naam AS user_name
                 FROM Reviews r
                 JOIN Products p ON r.artikelnr = p.artikelnr
                 JOIN User u ON r.user_id = u.user_id
                 ORDER BY r.review_date DESC";
$result_feedback = $conn->query($sql_feedback);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Beheer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 50px auto;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        h1 {
            text-align: center;
            color:rgb(57, 36, 245);
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            text-align: left;
            padding: 10px;
            border: 1px solid #ddd;
        }

        table th {
            background-color: #f4f4f9;
            color: #555;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        button {
            background-color:rgb(57, 36, 245);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color:rgb(11, 4, 79);
        }

        .back-button {
            display: block;
            margin: 0 auto;
            text-align: center;
        }

        form {
            margin: 0;
        }

        @media (max-width: 768px) {
            table {
                font-size: 14px;
            }

            button {
                width: 100%;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Feedback Beheer</h1>
        <?php if ($result_feedback->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Gebruiker</th>
                        <th>Product</th>
                        <th>Rating</th>
                        <th>Feedback</th>
                        <th>Datum</th>
                        <th>Actie</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result_feedback->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['user_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['rating']); ?>/5</td>
                            <td><?php echo nl2br(htmlspecialchars($row['review_text'])); ?></td>
                            <td><?php echo htmlspecialchars($row['review_date']); ?></td>
                            <td>
                                <form method="post" action="">
                                    <input type="hidden" name="review_id" value="<?php echo $row['review_id']; ?>">
                                    <button type="submit" name="delete_feedback" onclick="return confirm('Weet je zeker dat je deze feedback wilt verwijderen?');">Verwijderen</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Er is geen feedback beschikbaar.</p>
        <?php endif; ?>

        <button class="back-button" onclick="window.location.href='adminPanel.php'">Terug naar admin panel</button>
    </div>
</body>
</html>
