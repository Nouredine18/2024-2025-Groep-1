<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_error_log.txt');
error_reporting(E_ALL);
include 'connect.php';
session_start();

$user_id = $_SESSION["user_id"];

// Haal bestaande adressen op
$sqlSelect = "SELECT address_id, straat, huisnummer, postcode, stad, land FROM Adres WHERE user_id = ?";
$stmtSelect = $conn->prepare($sqlSelect);
$stmtSelect->bind_param("i", $user_id);
$stmtSelect->execute();
$resultSelect = $stmtSelect->get_result();
$addressCount = $resultSelect->num_rows;

// Haal schoenmaat op
$sqlSelectSchoenmaat = "SELECT schoenmaat FROM User WHERE user_id = ?";
$stmtSelectS = $conn->prepare($sqlSelectSchoenmaat);
$stmtSelectS->bind_param("i", $user_id);
$stmtSelectS->execute();
$resultSelectS = $stmtSelectS->get_result();
$schoenmaat = $resultSelectS->fetch_assoc()['schoenmaat']; // Fetch shoe size once

// Haal betaalde producten op
$sqlProducts = "SELECT B.artikelnr, P.naam AS product_naam, B.aantal, B.koopdatum 
                FROM BoughtProducts B
                JOIN Products P ON B.artikelnr = P.artikelnr
                WHERE B.user_id = ? AND B.betaald = 1";

$stmtProducts = $conn->prepare($sqlProducts);
$stmtProducts->bind_param("i", $user_id);
$stmtProducts->execute();
$resultProducts = $stmtProducts->get_result();

// Nieuw adres toevoegen
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_address'])) {
    if ($addressCount < 3) {
        $straat = trim($_POST['straat']);
        $huisnummer = trim($_POST['huisnummer']);
        $postcode = trim($_POST['postcode']);
        $stad = trim($_POST['stad']);
        $land = trim($_POST['land']);
        $schoenmaatInput = trim($_POST['schoenmaat']);

        // Insert the new address
        $sqlInsert = "INSERT INTO Adres (user_id, straat, huisnummer, postcode, stad, land) VALUES (?, ?, ?, ?, ?, ?)";
        $stmtInsert = $conn->prepare($sqlInsert);
        $stmtInsert->bind_param("isssss", $user_id, $straat, $huisnummer, $postcode, $stad, $land);
        
        if ($stmtInsert->execute()) {
            echo "<p class='success'>Adres succesvol toegevoegd!</p>";
            header("Refresh:0");
            exit;
        } else {
            echo "<p class='error'>Fout bij het toevoegen van adres.</p>";
        }

        // Update shoe size if provided
        if (!empty($schoenmaatInput)) {
            $sqlUpdate = "UPDATE User SET schoenmaat = ? WHERE user_id = ?";
            $stmtUpdate = $conn->prepare($sqlUpdate);
            $stmtUpdate->bind_param("ii", $schoenmaatInput, $user_id);
            
            if ($stmtUpdate->execute()) {
                echo "<p class='success'>Schoenmaat succesvol bijgewerkt!</p>";
            } else {
                echo "<p class='error'>Fout bij het bijwerken van schoenmaat.</p>";
            }
        }
    } else {
        echo "<p class='error'>U kunt maximaal 3 adressen toevoegen.</p>";
    }
}

// Adres verwijderen
if (isset($_GET['delete_address'])) {
    $deleteId = intval($_GET['delete_address']);
    $sqlDelete = "DELETE FROM Adres WHERE user_id = ? AND address_id = ?";
    $stmtDelete = $conn->prepare($sqlDelete);
    $stmtDelete->bind_param("ii", $user_id, $deleteId);
    
    if ($stmtDelete->execute()) {
        echo "<p class='success'>Adres verwijderd.</p>";
        header("Refresh:0");
        exit;
    } else {
        echo "<p class='error'>Fout bij verwijderen.</p>";
    }
}

// Vraag insturen
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_question'])) {
    $vraag = trim($_POST['question']);
    if (!empty($vraag)) {
        $sqlVraag = "INSERT INTO Vragen (user_id, vraag) VALUES (?, ?)";
        $stmtVraag = $conn->prepare($sqlVraag);
        $stmtVraag->bind_param("is", $user_id, $vraag);
        
        if ($stmtVraag->execute()) {
            echo "<p class='success'>Vraag verzonden.</p>";
        } else {
            echo "<p class='error'>Fout bij verzenden.</p>";
        }
    }
}

?>


<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Mijn Account</title>
    <style>
        body {
            background-color: #001f3f;
            color: white;
            font-family: Arial, sans-serif;
            padding: 20px;
            text-align: center;
        }
        h2 { color: #ffdc00; }
        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ffffff;
            padding: 10px;
            text-align: left;
        }
        th { background-color: #0056b3; }
        tr:nth-child(even) { background-color: #003366; }
        a { color: #ffdc00; text-decoration: none; }
        a:hover { color: #ffffff; }
        form {
            border: 1px solid #0056b3;
            padding: 20px;
            background-color: #003366;
            width: 50%;
            margin: auto;
            border-radius: 10px;
        }
        label { display: block; margin: 10px 0 5px; }
        input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ffffff;
            background-color: #002244;
            color: white;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #ffdc00;
            color: #001f3f;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        input[type="submit"]:hover { background-color: #ffcc00; }
        .success { color: #00ff00; }
        .error { color: #ff3333; }
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #ffdc00;
            color: #001f3f;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }
        .back-btn:hover { background-color: #ffcc00; }
    </style>
</head>
<body>

<h2>Mijn Adressen</h2>
<table>
    <tr><th>Straat</th><th>Huisnummer</th><th>Postcode</th><th>Stad</th><th>Land</th><th>Schoenmaat</th><th>Acties</th></tr>
    <?php while ($address = $resultSelect->fetch_assoc()): ?>
        <tr>
            <td><?php echo $address['straat']; ?></td>
            <td><?php echo $address['huisnummer']; ?></td>
            <td><?php echo $address['postcode']; ?></td>
            <td><?php echo $address['stad']; ?></td>
            <td><?php echo $address['land']; ?></td>
            <td><?php echo $schoenmaat; ?></td>
            <td><a href="?delete_address=<?php echo $address['address_id']; ?>">Verwijderen</a></td>
        </tr>
    <?php endwhile; ?>
</table>

<?php if ($addressCount < 3): ?>
    <h2>Nieuw Adres Toevoegen</h2>
    <form method="post">
        <label>Straat:</label><input type="text" name="straat" required>
        <label>Huisnummer:</label><input type="text" name="huisnummer" required>
        <label>Postcode:</label><input type="text" name="postcode" required>
        <label>Stad:</label><input type="text" name="stad" required>
        <label>Land:</label><input type="text" name="land" required>
        <label>Schoenmaat:</label><input type="number" name="schoenmaat">
        <input type="submit" name="add_address" value="Toevoegen">
    </form>
<?php endif; ?>

<h2>Stel een Vraag</h2>
<form method="post">
    <label for="question">Uw vraag:</label>
    <textarea id="question" name="question" required></textarea>
    <input type="submit" name="submit_question" value="Versturen">
</form>

<a href="javascript:history.back()" class="back-btn">⬅ Terug</a>

</body>
</html>