<?php
include 'connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST['discount'] as $artikelnr => $discount) {
        // Update the product with the new discount
        $query = "UPDATE Products SET discount = ? WHERE artikelnr = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('di', $discount, $artikelnr);
        if (!$stmt->execute()) {
            echo "Error applying discount to product $artikelnr.<br>";
        }
    }
    echo "Discounts applied successfully!";
}

// Fetch all products to display in the form
$query = "SELECT artikelnr, naam, prijs, discount FROM Products";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Discounts</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        h1 {
            text-align: center;
            font-size: 30px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
            font-weight: 600;
        }

        input[type="number"] {
            width: 80px;
            padding: 5px;
            margin-right: 10px;
        }

        button {
            padding: 10px 20px;
            background-color: #111;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #333;
        }
        
        .back-button {
            display: block;
            margin: 20px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <h1>Apply Discounts to Products</h1>
    <form method="POST" action="apply_discount.php">
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Current Price</th>
                    <th>Discount (%)</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['naam']) ?></td>
                        <td>€<?= number_format($row['prijs'], 2) ?></td>
                        <td>
                            <input type="number" name="discount[<?= htmlspecialchars($row['artikelnr']) ?>]" step="0.01" value="<?= htmlspecialchars($row['discount']) ?>">
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <button type="submit">Apply Discounts</button>
    </form>

    <div class="back-button">
        <a href="adminPanel.php">
            <button type="button">Back to Admin Panel</button>
        </a>
    </div>
</body>
</html>
