<?php
session_start();
include 'connect.php';

// Haal de producten op uit de database, inclusief de korting
$sql = "SELECT artikelnr, naam, purchase_price, prijs, discount FROM Products";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winstberekeningen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color:rgb(57, 36, 245);
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color:rgb(57, 36, 245);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            margin: 20px auto;
            display: block;
            width: 200px;
        }

        .button:hover {
            background-color:rgb(31, 11, 94);
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

    </style>
</head>
<body>

    <div class="container">
        <h2>Winstberekeningen per Product</h2>

        <?php
        if ($result->num_rows > 0) {
            // Variabelen voor de totale winst
            $total_profit = 0;

            echo "<table>
                    <tr>
                        <th>Productnaam</th>
                        <th>Gekochte Prijs</th>
                        <th>Verkoopprijs</th>
                        <th>Korting (%)</th>
                        <th>Winst per Product</th>
                    </tr>";

            // Loop door de resultaten
            while ($row = $result->fetch_assoc()) {
                $purchase_price = $row['purchase_price'];
                $sale_price = $row['prijs'];
                $product_name = $row['naam'];
                $discount = $row['discount'];

                // Bereken de prijs na korting
                $discounted_price = $sale_price - ($sale_price * ($discount / 100));

                // Bereken de winst per product na korting
                $profit = $discounted_price - $purchase_price;

                // Voeg de winst toe aan de totale winst
                $total_profit += $profit;

                echo "<tr>
                        <td>" . htmlspecialchars($product_name) . "</td>
                        <td>" . number_format($purchase_price, 2) . "</td>
                        <td>" . number_format($sale_price, 2) . "</td>
                        <td>" . number_format($discount, 2) . "%</td>
                        <td>" . number_format($profit, 2) . "</td>
                      </tr>";
            }

            // Toon de totale winst
            echo "<tr>
                    <td colspan='4' style='text-align: right;'><strong>Totale Winst:</strong></td>
                    <td><strong>" . number_format($total_profit, 2) . "</strong></td>
                  </tr>";
            echo "</table>";
        } else {
            echo "<p>Geen producten gevonden.</p>";
        }

        $conn->close();
        ?>

        <!-- Knop naar het Admin Panel -->
        <a href="adminPanel.php" class="button">Terug naar Admin Panel</a>
    </div>

</body>
</html>
