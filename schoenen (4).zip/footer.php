<?php
// Maak verbinding met de database
include 'connect.php';

// Haal alle sociale media links op
$sql_social_links = "SELECT * FROM SocialMediaLinks";
$result_social_links = $conn->query($sql_social_links);

// Sluit de databaseverbinding
$conn->close();
?>

<footer>
    <style>
        footer {
            background: linear-gradient(145deg, #333, #222); /* Subtiele gradiënt */
            color: #fff;
            padding: 40px 20px;
            text-align: center;
            margin-top: auto; /* Zorg ervoor dat de footer onderaan blijft */
            font-family: 'Oswald', sans-serif; /* Gebruik het Oswald-font */
            box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.2); /* Schaduw aan de bovenkant */
        }

        footer p {
            margin: 0;
            padding: 10px 0;
            font-size: 1em;
            color: #ccc; /* Lichtgrijze tekst voor betere leesbaarheid */
        }

        .social-media {
            margin-top: 20px;
        }

        .social-media h3 {
            margin-bottom: 15px;
            font-family: 'Oswald', sans-serif; /* Gebruik het Oswald-font */
            font-size: 1.5em;
            color: #fff;
            text-transform: uppercase; /* Tekst in hoofdletters */
            letter-spacing: 1px; /* Meer ruimte tussen letters */
        }

        .social-media ul {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: center;
            gap: 20px; /* Meer ruimte tussen de links */
            flex-wrap: wrap; /* Zorg ervoor dat links op kleine schermen naar een nieuwe regel gaan */
        }

        .social-media ul li {
            display: inline;
        }

        .social-media ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 1.1em;
            transition: all 0.3s ease; /* Vloeiende overgang voor hover-effect */
            display: flex;
            align-items: center;
            gap: 8px; /* Ruimte tussen icoon en tekst */
            padding: 10px 15px; /* Meer padding voor betere klikbaarheid */
            border-radius: 5px; /* Afgeronde hoeken */
            background: rgba(255, 255, 255, 0.1); /* Subtiele achtergrond voor links */
        }

        .social-media ul li a:hover {
            background: rgba(255, 255, 255, 0.2); /* Lichtere achtergrond bij hover */
            transform: translateY(-3px); /* Licht omhoog bewegen bij hover */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Schaduw bij hover */
        }

        .social-media ul li a i {
            font-size: 1.2em; /* Iets grotere iconen */
        }

        /* Responsive design voor kleine schermen */
        @media (max-width: 768px) {
            .social-media ul {
                gap: 10px; /* Minder ruimte tussen links op kleine schermen */
            }

            .social-media ul li a {
                padding: 8px 12px; /* Minder padding op kleine schermen */
                font-size: 1em; /* Kleinere tekst op kleine schermen */
            }
        }
    </style>

    <p>&copy; 2024 Schoenen Wijns. Alle rechten voorbehouden.</p>

    <div class="social-media">
        <h3>Volg ons op:</h3>
        <ul>
            <?php if ($result_social_links && $result_social_links->num_rows > 0) : ?>
                <?php while ($row = $result_social_links->fetch_assoc()) : ?>
                    <li>
                        <a href="<?php echo htmlspecialchars($row['link']); ?>" target="_blank">
                            <?php
                            $platform = strtolower($row['platform']);
                            $icon = 'fas fa-link'; // Standaard icoon
                            if (strpos($platform, 'facebook') !== false) {
                                $icon = 'fab fa-facebook-f';
                            } elseif (strpos($platform, 'instagram') !== false) {
                                $icon = 'fab fa-instagram';
                            } elseif (strpos($platform, 'twitter') !== false) {
                                $icon = 'fab fa-twitter';
                            } elseif (strpos($platform, 'linkedin') !== false) {
                                $icon = 'fab fa-linkedin-in';
                            } elseif (strpos($platform, 'youtube') !== false) {
                                $icon = 'fab fa-youtube';
                            } elseif (strpos($platform, 'pinterest') !== false) {
                                $icon = 'fab fa-pinterest';
                            } elseif (strpos($platform, 'tiktok') !== false) {
                                $icon = 'fab fa-tiktok';
                            }
                            ?>
                            <i class="<?php echo $icon; ?>"></i> <!-- Icoon weergeven -->
                            <?php echo htmlspecialchars($row['platform']); ?> <!-- Platformnaam weergeven -->
                        </a>
                    </li>
                <?php endwhile; ?>
            <?php else : ?>
                <li>Geen links gevonden.</li>
            <?php endif; ?>
        </ul>
    </div>
</footer>