<?php
session_start();
include 'connect.php';

// Functie om rapporten te genereren
function generateReport($conn, $year, $month) {
    $dateCondition = "";

    // Controleer of het jaar geldig is
    $currentYear = date("Y");
    if ($year > $currentYear) {
        return "<tr><td colspan='5'><strong>De datum is niet beschikbaar (toekomstig jaar).</strong></td></tr>";
    }

    // Bepaal de tijdsfilter
    if ($month !== 'all') {
        $dateCondition = "AND MONTH(f.created_at) = $month";
    }

    // SQL-query om de factuurgegevens op te halen
    $sql = "SELECT p.naam, p.purchase_price, p.prijs, p.discount, f.created_at 
            FROM factuur f
            JOIN factuur_producten fp ON f.factuur_id = fp.factuur_id
            JOIN Products p ON fp.artikelnr = p.artikelnr
            WHERE YEAR(f.created_at) = $year $dateCondition";
    
    $result = $conn->query($sql);
    $total_profit = 0;
    $reportData = "";

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $purchase_price = $row['purchase_price'];
            $sale_price = $row['prijs'];
            $discount = $row['discount'];
            $discounted_price = $sale_price - ($sale_price * ($discount / 100));
            $profit = $discounted_price - $purchase_price;
            $total_profit += $profit;

            $reportData .= "<tr>
                <td>" . htmlspecialchars($row['naam']) . "</td>
                <td>" . number_format($purchase_price, 2) . "</td>
                <td>" . number_format($sale_price, 2) . "</td>
                <td>" . number_format($discount, 2) . "%</td>
                <td>" . number_format($profit, 2) . "</td>
            </tr>";
        }

        $reportData .= "<tr>
            <td colspan='4' style='text-align: right;'><strong>Totaal Winst:</strong></td>
            <td><strong>" . number_format($total_profit, 2) . "</strong></td>
        </tr>";
    } else {
        $reportData = "<tr><td colspan='5'><strong>Geen verkopen gevonden voor deze periode.</strong></td></tr>";
    }

    return $reportData;
}

// Ophalen van jaar en maand vanuit de URL
$selectedYear = isset($_GET['year']) ? intval($_GET['year']) : date("Y");
$selectedMonth = isset($_GET['month']) ? $_GET['month'] : 'all';

// Genereer rapport
$report = generateReport($conn, $selectedYear, $selectedMonth);

$conn->close();
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapportage</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(85, 69, 231);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
            margin: 10px;
        }

        .button:hover {
            background-color: rgb(31, 11, 94);
        }

        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: rgb(85, 69, 231);
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        
        .back-button {
            display: block;
            width: 150px;
            margin: 20px auto;
            text-align: center;
            background-color: red;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }

        .back-button:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Rapportage voor <?php echo $selectedYear; ?></h2>

    <div style="text-align: center;">
        <a href="?year=<?php echo date("Y"); ?>&month=all" class="button">Huidig Jaar</a>
        <a href="?year=<?php echo date("Y"); ?>&month=<?php echo date("m"); ?>" class="button">Huidige Maand</a>
        <a href="adminPanel.php" class="button">Terug naar Admin Panel</a>
    </div>

    <form method="GET" style="text-align: center; margin-top: 20px;">
        <label for="year">Kies Jaar:</label>
        <select name="year" id="year">
            <?php for ($i = 2020; $i <= date("Y"); $i++): ?>
                <option value="<?php echo $i; ?>" <?php if ($selectedYear == $i) echo "selected"; ?>><?php echo $i; ?></option>
            <?php endfor; ?>
        </select>

        <label for="month">Kies Maand:</label>
        <select name="month" id="month">
            <option value="all">Alle</option>
            <?php for ($m = 1; $m <= 12; $m++): ?>
                <option value="<?php echo $m; ?>" <?php if ($selectedMonth == $m) echo "selected"; ?>>
                    <?php echo date("F", mktime(0, 0, 0, $m, 1)); ?>
                </option>
            <?php endfor; ?>
        </select>

        <button type="submit" class="button">Genereer Rapport</button>
    </form>

    <h3>Verkoopgegevens</h3>
    <table>
        <tr>
            <th>Productnaam</th>
            <th>Gekochte Prijs</th>
            <th>Verkoopprijs</th>
            <th>Korting (%)</th>
            <th>Winst per Product</th>
        </tr>
        <?= $report; ?>
    </table>

    <a href="javascript:history.back()" class="back-button">Terug</a>
</div>

</body>
</html>
