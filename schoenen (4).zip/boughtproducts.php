<?php
include 'connect.php';
session_start();

$user_id = $_SESSION["user_id"];

// Haal gekochte items op voor deze gebruiker uit de BoughtProducts-tabel, met productnaam van de Products-tabel
$sqlBoughtProducts = "
    SELECT b.id, p.naam AS product_name, p.prijs, b.koopdatum AS purchase_date, b.return_requested
    FROM BoughtProducts b
    JOIN Products p ON b.artikelnr = p.artikelnr
    WHERE b.user_id = ?
";

$stmtBoughtItems = $conn->prepare($sqlBoughtProducts); // Gebruik de correcte variabele naam
$stmtBoughtItems->bind_param("i", $user_id);
$stmtBoughtItems->execute();
$resultBoughtItems = $stmtBoughtItems->get_result();

// Retour aanvragen voor één product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_return'])) {
    $order_id = intval($_POST['order_id']);

    // Controleer of de bestelling bij deze gebruiker hoort in de BoughtProducts-tabel
    $sqlCheckOrder = "SELECT id FROM BoughtProducts WHERE user_id = ? AND id = ?";
    $stmtCheckOrder = $conn->prepare($sqlCheckOrder);
    $stmtCheckOrder->bind_param("ii", $user_id, $order_id);
    $stmtCheckOrder->execute();
    $resultCheckOrder = $stmtCheckOrder->get_result();

    if ($resultCheckOrder->num_rows > 0) {
        // Markeer bestelling als retour aangevraagd
        $sqlRequestReturn = "UPDATE BoughtProducts SET return_requested = 1 WHERE id = ?";
        $stmtRequestReturn = $conn->prepare($sqlRequestReturn);
        $stmtRequestReturn->bind_param("i", $order_id);

        if ($stmtRequestReturn->execute()) {
            echo "<p style='color:green;'>Retour aangevraagd voor bestelling $order_id.</p>";
        } else {
            echo "<p style='color:red;'>Fout bij het aanvragen van retour: " . $stmtRequestReturn->error . "</p>";
        }
    } else {
        echo "<p style='color:red;'>Ongeldige bestelling.</p>";
    }
}

// Retour aanvragen voor meerdere producten
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_multiple_return'])) {
    if (isset($_POST['selected_items'])) {
        // Verkrijg de geselecteerde items
        $selected_items = $_POST['selected_items'];

        // Verwerk elk geselecteerd item
        foreach ($selected_items as $order_id) {
            // Controleer of de bestelling bij deze gebruiker hoort in de BoughtProducts-tabel
            $sqlCheckOrder = "SELECT id FROM BoughtProducts WHERE user_id = ? AND id = ?";
            $stmtCheckOrder = $conn->prepare($sqlCheckOrder);
            $stmtCheckOrder->bind_param("ii", $user_id, $order_id);
            $stmtCheckOrder->execute();
            $resultCheckOrder = $stmtCheckOrder->get_result();

            if ($resultCheckOrder->num_rows > 0) {
                // Markeer bestelling als retour aangevraagd
                $sqlRequestReturn = "UPDATE BoughtProducts SET return_requested = 1 WHERE id = ?";
                $stmtRequestReturn = $conn->prepare($sqlRequestReturn);
                $stmtRequestReturn->bind_param("i", $order_id);
                
                if ($stmtRequestReturn->execute()) {
                    echo "<p style='color:green;'>Retour aangevraagd voor bestelling $order_id.</p>";
                } else {
                    echo "<p style='color:red;'>Fout bij het aanvragen van retour voor bestelling $order_id: " . $stmtRequestReturn->error . "</p>";
                }
            } else {
                echo "<p style='color:red;'>Ongeldige bestelling $order_id.</p>";
            }
        }
    } else {
        echo "<p style='color:red;'>Geen producten geselecteerd.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Gekochte Items</title>
    <style>
       body {
    background-color: #001f3f;
    color: white;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    border: 1px solid #FFFFFF;
    padding: 10px;
    text-align: left;
}

th {
    background-color: #0056b3;
}

tr:nth-child(even) {
    background-color: #003366;
}

form {
    margin: 0;
    margin-top: 20px; /* Toegevoegd om ruimte boven de formulierknop te creëren */
}

button {
    background-color: #0056b3;
    color: white;
    padding: 5px 10px;
    border: none;
    cursor: pointer;
    margin-top: 10px; /* Toegevoegd om wat ruimte boven de knop te creëren */
}

button:hover {
    background-color: #003f7f;
}

.back-to-profile {
    display: inline-block;
    margin-top: 20px;
    background-color: #0056b3;
    color: white;
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 5px;
}

.back-to-profile:hover {
    background-color: #003f7f;
}

    </style>
</head>
<body>
    <h2>Gekochte Items</h2>
    <form method="post" action="">
        <table>
            <tr>
                <th>Selecteer</th>
                <th>Order ID</th>
                <th>Productnaam</th>
                <th>Aankoopdatum</th>
                <th>Prijs</th>
                <th>Acties</th>
            </tr>
            <?php while ($item = $resultBoughtItems->fetch_assoc()): ?>
            <tr>
                <td><input type="checkbox" name="selected_items[]" value="<?php echo $item['id']; ?>"></td> <!-- Checkbox voor selectie -->
                <td><?php echo $item['id']; ?></td>
                <td><?php echo $item['product_name']; ?></td>
                <td><?php echo $item['purchase_date']; ?></td>
                <td>&euro;<?php echo number_format($item['prijs'], 2); ?></td>
                <td>
                    <?php if ($item['return_requested'] == 0): ?>
                        <form method="post" action="">
                            <input type="hidden" name="order_id" value="<?php echo $item['id']; ?>"> <!-- Gebruik id van boughtproducts -->
                            <button type="submit" name="request_return">Retour Aanvragen</button>
                        </form>
                    <?php else: ?>
                        Retour aangevraagd
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>

        <!-- Knop voor alle geselecteerde retour aanvragen -->
        <button type="submit" name="request_multiple_return">Retour Aanvragen voor Geselecteerde Producten</button>
    </form>

    <a href="profile.php" class="back-to-profile">Terug naar Profiel</a>
</body>
</html>
