<?php
session_start();
echo "Payment canceled!";
?>