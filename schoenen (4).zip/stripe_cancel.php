<?php
session_start();
echo "Stripe payment canceled!";
echo '<br><a href="index.php">Go Back</a>';
?>