<?php
session_start();
echo "PayPal payment canceled!";
?>