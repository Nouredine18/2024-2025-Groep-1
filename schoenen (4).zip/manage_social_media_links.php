<?php
include 'connect.php';
session_start();

// Controleer of de gebruiker is ingelogd en admin is
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'admin') {
    header("Location: login_register.php"); // Redirect naar login als niet ingelogd
    exit();
}

// Verwerk het toevoegen van een nieuwe sociale media link
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_link'])) {
    $platform = $_POST['platform'];
    $link = $_POST['link'];

    $sql_insert = "INSERT INTO SocialMediaLinks (platform, link) VALUES (?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    if ($stmt_insert) {
        $stmt_insert->bind_param("ss", $platform, $link);
        if ($stmt_insert->execute()) {
            $success_message = "Social media link succesvol toegevoegd.";
        } else {
            $error_message = "Fout bij het toevoegen van de link.";
        }
        $stmt_insert->close();
    }
}

// Verwerk het verwijderen van een sociale media link
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    $sql_delete = "DELETE FROM SocialMediaLinks WHERE id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    if ($stmt_delete) {
        $stmt_delete->bind_param("i", $delete_id);
        if ($stmt_delete->execute()) {
            $success_message = "Social media link succesvol verwijderd.";
        } else {
            $error_message = "Fout bij het verwijderen van de link.";
        }
        $stmt_delete->close();
    }
}

// Haal alle sociale media links op
$sql_social_links = "SELECT * FROM SocialMediaLinks";
$result_social_links = $conn->query($sql_social_links);

// Sluit de databaseverbinding
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beheer Sociale Media Links</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #f8f9fa;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 10px 0;
        }

        nav {
            display: flex;
            justify-content: center; /* Centreert de navigatielinks horizontaal */
        }

        nav ul {
            display: flex;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            margin: 0 15px; /* Ruimte tussen de links */
        }

        nav ul li a {
            text-decoration: none; /* Verwijdert onderstreping */
            color: #333; /* Kleur van de links */
            font-weight: bold; /* Links dikker maken */
            font-size: 16px;
        }

        nav ul li a:hover {
            color: #007bff; /* Kleur bij hover */
        }

        main {
            padding: 20px;
        }

        .form-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .form-container input[type="text"], .form-container input[type="url"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-container button , .back-button  {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .back-button:hover {
    background-color: #0056b3;
}

        .form-container button:hover {
            background-color: #0056b3;
        }

        .social-links {
            max-width: 600px;
            margin: 20px auto;
            padding: 0;
            list-style: none;
        }

        .social-links li {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: #fff;
            margin: 10px 0;
            padding: 10px;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .social-links a {
            text-decoration: none;
            color: #333;
            display: flex;
            align-items: center;
        }

        .social-links a i {
            margin-right: 10px;
            font-size: 20px;
        }

        .social-links .delete-link {
            color: red;
            font-size: 18px;
        }

        .success, .error {
            max-width: 400px;
            margin: 20px auto;
            padding: 10px;
            text-align: center;
            border-radius: 4px;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }



    </style>
</head>
<body>

<main>
    <h2 style="text-align: center;">Beheer Sociale Media Links</h2>

    <?php if (isset($success_message)) : ?>
        <div class="success"><?php echo $success_message; ?></div>
    <?php elseif (isset($error_message)) : ?>
        <div class="error"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <section>
        <h3 style="text-align: center;">Voeg een nieuwe sociale media link toe</h3>
        <form action="manage_social_media_links.php" method="post" class="form-container">
            <label for="platform">Platform</label>
            <input type="text" name="platform" id="platform" placeholder="Bijv. Facebook" required>

            <label for="link">Link</label>
            <input type="url" name="link" id="link" placeholder="Bijv. https://facebook.com" required>

            <button type="submit" name="add_link">Link Toevoegen</button>
            <a href="adminPanel.php" class="back-button">Terug naar Admin Panel</a>

        </form>
    </section>

    <section>
        <h3 style="text-align: center;">Bestaande Sociale Media Links</h3>
        <?php if ($result_social_links && $result_social_links->num_rows > 0) : ?>
            <ul class="social-links">
                <?php while ($row = $result_social_links->fetch_assoc()) : ?>
                    <li>
                        <a href="<?php echo htmlspecialchars($row['link']); ?>" target="_blank">
                            <?php
                            $platform = strtolower($row['platform']);
                            $icon = '';
                            if (strpos($platform, 'facebook') !== false) {
                                $icon = 'fab fa-facebook-f';
                            } elseif (strpos($platform, 'instagram') !== false) {
                                $icon = 'fab fa-instagram';
                            } elseif (strpos($platform, 'twitter') !== false) {
                                $icon = 'fab fa-twitter';
                            } elseif (strpos($platform, 'linkedin') !== false) {
                                $icon = 'fab fa-linkedin';
                            } else {
                                $icon = 'fas fa-link';
                            }
                            ?>
                            <i class="<?php echo $icon; ?>"></i>
                            <?php echo htmlspecialchars($row['platform']); ?>
                        </a>
                        <a href="manage_social_media_links.php?delete_id=<?php echo $row['id']; ?>" 
                           onclick="return confirm('Weet je zeker dat je deze link wilt verwijderen?');" 
                           class="delete-link">
                           <i class="fas fa-trash"></i>
                        </a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else : ?>
            <p style="text-align: center;">Geen links gevonden.</p>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
